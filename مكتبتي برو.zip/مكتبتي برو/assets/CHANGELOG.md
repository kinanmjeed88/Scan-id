# Changelog

All notable changes to مكتبتي برو (Maktabati Pro) for Android. Newest first.

## 1.2.0 — 2026-10-18

### Added
- **A reminder to rate the app.** After the second print, PDF, saved sheet,
  export or share, the welcome screen asks once for a Google Play rating:
  «قيّم التطبيق» opens the app's page on Play, «لاحقاً» asks again five
  outputs later (three times at most), «لا تذكّرني» never asks again. It
  waits until the cropping lesson has been offered, and never interrupts work.
- **«قيّم التطبيق على Google Play»** in About, for whenever someone wants to.
- **«يوجد تحديث جديد».** When Google Play has a newer version, the welcome
  screen says so. «تحديث الآن» runs Play's own update and restarts the app
  (or opens the Play page); «لاحقاً» waits until the next launch. Play is
  asked through the Play Store app on the phone: the app still has no
  internet permission.

## 1.1.9 — 2026-10-15

### Fixed
- **«تدوير الصورة» in the images sheet seemed to do nothing.** The turn was
  kept (copies added afterwards came out turned) but the card in the list
  still showed the image as it was. The thumbnail now turns with it.

## 1.1.8 — 2026-10-15

### Added
- **Auto capture.** The camera looks for the card in every preview frame,
  outlines it where it sits, and takes the photo by itself (with a short
  buzz) once the card has held still for under a second. It will not shoot
  the same card twice: the next photo waits for the card to be moved or
  swapped. «⚡ تلقائي» turns it off and on, and the choice is remembered. A
  camera that cannot analyse frames while shooting still works by hand.

### Changed
- **A third of the size.** OpenCV is now a slim build of just the parts the
  app uses (core, imgproc, photo): about 8 MB of native code per phone
  instead of 25, so the download and the installed app shrink accordingly.
  The recipe is in `opencv-slim/`.

### Fixed
- **Card backs photographed sideways came out upside down.** A back has no
  face to read the way up from; it now turns the way the last front did, and
  anticlockwise when there is none (how phones held upright photograph a
  card on its side). Checked on real sideways photos of a front and a back.

## 1.1.7 — 2026-10-15

### Changed
- **Nothing goes on the paper by itself.** Cropped IDs wait in «الصور
  المستوردة», which opens on its own when new ones arrive; the user ticks
  the ones to print and adds them. An empty page says so and opens the list.
- **Whole cards in the image lists.** The imported-images sheet and the strip
  under the page show each card complete, not a cut-out of its middle, so it
  is easy to tell whose ID it is.

### Removed
- **«متابعة الجلسة السابقة».** Every launch starts clean: the last session's
  ID images are deleted when the app opens, and «فتح الصور» no longer asks
  before starting over. Work survives only the system pausing the app in the
  background, never a fresh launch.

### Fixed
- **Cards photographed sideways came out standing up.** A national ID or
  residence card that crops out taller than wide is now turned onto its side.
  Which way is read from the holder's photo (Android's on-device face finder;
  nothing leaves the phone); cards from one photo are turned together, so a
  back with no face follows its front. With no face at all, a clockwise turn.

## 1.1.6 — 2026-10-15

### Added
- **«تحدّي القصّاص», the cropping lesson as a game.** Offered once on first
  launch (and any time from 🎮 تدريب on the welcome screen or Settings): on
  a made-up practice card, the screen dims all but the next thing to do and
  a hand shows the move: tap the card, drag a loose corner home, pick the
  type, save. A star and a gentle buzz for each step, a hint when a move
  misses, a trophy at the end, and «ابدأ بصورك» goes straight to the photo
  picker. No real document ships with the app and nothing is saved.
- **Residence card and passport as document types.** Crop now offers هوية
  وطنية (8.56 × 5.4 cm), بطاقة سكن (9 × 6.1 cm), جواز (8.8 × 12.5 cm) and
  A4. The crop frame and auto-detect look for that shape, and the document
  is placed on the page at its real size (A4 fills the page).
- **Size bar on the layout page.** While a document is selected, its sizes
  sit right above its actions, the current one highlighted: one tap to
  switch between national ID, residence card, passport and fit to page.

### Fixed
- **A tap on a card selects the card, not the paper around it.** When the
  patch of paper or table under a card happened to be card-shaped, it was
  taken for the card and the real card inside it was dropped; a tap then
  selected the whole page. An outline that holds a much smaller card is now
  never taken for a card.
- **Corners move with a plain drag.** A long press was needed first, so a
  corner seemed impossible to move. A corner on the very edge of the screen
  can now be dragged without the phone's Back swipe taking over.

## 1.1.5 — 2026-10-14

### Added
- **How-to video:** a button at the top of the welcome screen opens the
  tutorial video (in TikTok, or the browser).

### Fixed
- **Auto-detect finds pale cards printed on a sheet of paper.** Copies of ID
  cards on a page (several fronts and backs) were often not found at all:
  their edges barely show against white paper, and a block of cards could
  be taken for one big card that hid all the cards inside it. A new pass
  finds the sheet and picks out whatever on it differs from the paper,
  even when the paper is shaded across the photo; an outline holding two or
  more cards is no longer taken for a card, nor is a skewed wedge of paper.
- Crop all takes only the cards, never the sheet under them or the photo's
  frame.

## 1.1.4 — 2026-10-12

### Added
- **Print options on the print screen:** colour or black and white, and one
  side or both sides (front and back, flipped on the long edge). Android's
  print dialog opens already set to them, with the printer list to pick from;
  the choices are kept for the next print. Black and white pages are also
  drawn in greys, so no colour ink is used even on a printer that ignores the
  setting, and the summary counts sheets for two-sided printing.

### Fixed
- **Print works again.** Since the app was put in Arabic (1.0.8), the print
  system refused every job ("Can print only from an activity"), so the
  print dialog never opened. The Arabic setting is now applied without
  replacing the activity's own context.
- The print preview and page thumbnails show the pages in greys when black
  and white is chosen.
- A quick double tap on Back no longer pops past the welcome screen to a
  blank window, and a double tap on a button no longer opens the next
  screen (print preview, camera, settings…) twice.
- Photos and print files of identity documents no longer stay behind in the
  cache: leaving the camera without Done removes its shots even as the
  screen closes, and ending a session (or starting a new one) removes the
  print PDFs and shared page pictures too.
- A save folder chosen in Settings that was later deleted (or whose access
  was withdrawn) is forgotten, and the folder picker opens again, instead of
  an error in English.
- Choosing a save folder whose access the system will not keep no longer
  closes the app, and neither does a phone without a file, folder or
  settings app for a picker; a half-written file is removed also when a
  page runs out of memory.
- A very large photo no longer closes the app when it is imported (it is
  skipped and named), opened on the Adjust screen, or Auto Enhanced.

## 1.1.3 — 2026-10-11

### Fixed
- Image and layer names show in Arabic ("صورة 1", "صورة 1 (نسخة)") instead
  of "Image 1", also in the Export IDs report.
- Installs from Google Play always carry the Arabic resources, whatever the
  phone's language (language splits are off in the app bundle).
- Saving, printing and sending many pages of full-size photos uses far less
  memory: each photo is let go once no later page needs it.
- A very large photo on the crop screen shows an error instead of closing
  the app.
- Tapping an ID while it is still being looked for no longer clears the
  busy state of another action.
- Images dropped by leaving an Import early free their previews, and an
  unreadable image is reported once, not on every change.

## 1.1.2 — 2026-10-10

### Fixed
- *Fit page* now always shows the whole A4 sheet, also on short or
  low-density screens (it used to stop at 20 % and cut the page off).
- The three template tiles are the same height when a name wraps.

## 1.1.1 — 2026-10-10

### Changed
- **Easier corners on the crop screen:**
  - **tap an ID to select it**: before any corner is placed, a tap inside a
    card outlines that card by itself (a tap on the paper still places a
    corner by hand). Other cards found in the photo stay outlined, so *Crop
    all* can take them too;
  - the corner markers are small rings, so the corner stays visible, with
    their numbers set outside the shape;
  - while a finger is down, placing or dragging a corner, a **magnifier** in
    a top corner shows the spot enlarged with a crosshair and the edge lines.

## 1.1.0 — 2026-10-10

### Added
- **Ready templates** (*قوالب*, next to Auto arrange): one tap lays every
  imported image out on the pages:
  - **front and back side by side** — image 1 is an ID's front, image 2 its
    back, and so on; the front on the right, its back on the left;
  - **front and back stacked** — the back under its front, two IDs across;
  - **single IDs** — eight to a page.
  Choose how many copies of each ID first; each template says how many
  pages it will make. It replaces what is on the pages, and Undo brings it
  back.
- **Quick send** (the send button in the top bar): the pages as one PDF, or
  as a picture per page, straight to WhatsApp (or WhatsApp Business) when it
  is installed, or to any other app.

### Changed
- The paper chip reads *A4 عمودي*; the orientation chip it replaces only ever
  had the one choice.

## 1.0.9 — 2026-10-10

### Changed
- **The print-IDs page on phones follows the new design:**
  - under the title: *A4*, *Portrait* and **Auto arrange**;
  - under the page: previous / *Page 1 of 2* / next, and **New page**;
  - a selected card shows Rotate, Duplicate, Lock, Delete and More, each
    named under its icon;
  - **Imported images (N) · N on the paper**: the images in a row, a tick on
    those already on the page; tap one to add it;
  - the ⌃ (or a swipe up) opens every image as a card: tick several, or
    *Select all*, then **Add selected to the paper (N)**. Each card shows
    *On the paper* when placed, and its ⋮ turns or removes the image.
  - Original size and Fit page moved to the ⋮ menu.
- Arabic plurals ("صورتين", "3 صور") are right on phones set to any
  language.

## 1.0.8 — 2026-10-10

### Changed
- **The app is now in Arabic** on every phone, and reads right to left:
  every screen, message, dialog and the privacy policy. Back and page arrows
  point the Arabic way; the page itself and its rulers stay as on paper.
- Counters read "1 من 2" so the numbers never show reversed.
- **A bigger A4 page** on phones: the paper size is now a small chip next to
  the page number, and **Imported images** became a drawer at the foot that
  shows only its handle. Tap it or swipe it up to open; it closes when you
  touch the page, swipe it down, or leave it for 5 seconds.

## 1.0.7 — 2026-10-10

### Changed
- **New look for the layout screen on phones** (*Print IDs*), light and
  simpler; everything it did before still works:
  - a white top bar with Back, Undo and a ⋮ menu (Text, Grid, Layers,
    Manage images, Save A4, Export IDs, New Page, Delete empty page, Clean Up);
  - *Paper size A4*, then the page with its rulers, and the page number
    with previous / next, New page and the zoom (tap it to fit) below it;
  - **Auto arrange** lays the page's cards out again in tidy rows (locked
    ones stay put; any that no longer fit go to a new page), and **Original
    size** puts cards back to true ID-card size (the selected card, or all);
  - while a card is selected, a bar with Rotate, Duplicate, Lock, Delete and
    more replaces those two buttons;
  - **Imported images (N)** as a strip: tap one to put it on the page, *Add
    all* for all of them, and + to add more;
  - **Print preview** and **Add ID** at the foot; Add ID opens a new *Add
    IDs* sheet: Take photo, Choose photos, Import file.
  Tablets keep the side-panel layout.

## 1.0.6 — 2026-10-10

### Added
- **Several documents in one photo** (front and back of an ID, or a whole
  sheet of cards):
  - *Auto-detect edges* now finds every card in the photo and outlines them
    all; each press moves to the next one. Small cards on a full sheet are
    found too, and an A4 sheet under the cards is no longer taken for a card.
  - **Crop all N documents** crops every card found in one tap, each into its
    own image.
  - **Crop another** saves this card and opens the same photo again for the
    next; cards already cropped show in green and are skipped by Auto-detect.
    *Done* ends that photo.
- **Cards go onto the A4 pages by themselves**: when the layout opens, every
  cropped card is placed, two to a row, with pages added as they fill; cards
  added later with Import are placed too. Undo takes it back, and a card you
  delete stays deleted. *Add all to the pages* in Sources does the same by
  hand.

### Fixed
- Messages with numbers read correctly ("1 document", "3 documents").

## 1.0.5 — 2026-10-10

### Changed
- **Cropping is back to the original flow**: the corners are no longer
  placed automatically when a picture opens; you tap the four corners
  yourself, as before. The *Auto-detect edges* button on the crop toolbar
  still places them when you press it. The *Auto-detect edges* setting is
  gone.

## 1.0.4 — 2026-10-09

### Changed
- **The developer's name is now Jaafer Sabah everywhere.** The app ID is
  `com.jaafersabah.maktabatipro` (fixed before the first Play release; it can
  never change afterwards), the code package matches it, and Export IDs
  folders are named `Jaafer_Scan_<date>_<time>`.

## 1.0.3 — 2026-10-09

### Added
- **Privacy policy** in *Settings → About*: nothing is collected, what the
  camera and picked photos are used for, where images are kept and when they
  are deleted. The same text is in `play/privacy-policy.html` for the Google
  Play listing.
- **Themed icon** (Android 13+): a one-colour version of the emblem, so the
  icon follows the wallpaper colours when themed icons are on.
- Chromebook support: the app now also ships for x86_64.
- The author's name is now spelled **Jaafer Sabah** (About, privacy policy).

### Changed
- Google Play readiness: no lint errors left. Messages are read in a
  configuration-aware way, so they follow a language or display change, and
  counts read correctly ("1 page", "3 pages").
- Removed unused resources and the legacy PNG launcher icons (not needed
  since Android 8).

## 1.0.2 — 2026-10-09

### Added
- **Automatic edge detection on the crop screen**: as each picture opens,
  the app finds the ID card (or page) and places the four corners for you.
  Nothing is cropped until you press *Save & Next*, so you always check the
  corners first, and you can move them or tap *Undo*. Turn it off in
  *Settings → Auto-detect edges*; the toolbar button still works either way.

### Improved
- Edge detection finds more cards: it now also tries softer edge thresholds
  and the card's shape against the background, and places each corner where
  the card's edges meet, so the rounded corners of an ID card are no longer
  clipped.

## 1.0.1 — 2026-10-08

### Changed
- Refined the launcher icon for small sizes: a clean camera/document emblem
  on a continuous teal-to-blue adaptive background. Removed the tiny repeated
  Arabic wordmark and white footer from the icon; the launcher label still
  shows مكتبتي برو. Artwork fits the circular safe area without an inset
  rounded-square badge. The splash screen uses the same clean emblem.

## 1.0.0 — unreleased (in development)

### Added
- **New name, مكتبتي برو**: on the launcher, the welcome screen and About,
  and as the save folder `Documents/مكتبتي برو`. The app ID is now
  `com.jaafersabah.maktabatipro`, and files are named `MaktabatiPro-…`.
- **New logo** (مكتبتي برو) on the launcher, the splash screen, the welcome
  card and the About page, from a 1254 px original, so every size is sharp,
  including the 512 px Play Store icon (`logo/v2/`). On the launcher the
  logo is scaled so the whole Arabic name stays inside round icon masks.
- **Settings**: default document type (ID Card / A4 Document), Export IDs size
  limit (10–5000 KB in steps of 10, default 100), save location (the default
  `Documents/مكتبتي برو` or a folder you choose), and theme (System /
  Always dark — the welcome screen follows it; the editing screens are always
  dark). Changes apply at once and are used the next time you crop or export;
  **Reset** puts the document type, size limit and folder back, as on the
  desktop.
- **About**: logo, name, version, author, the offline promise, and this
  changelog.
- Readable text everywhere (WCAG AA, 4.5:1): status and link text on the dark
  panels uses lighter versions of the green, amber, red and blue (the
  original colours stay for buttons, borders and icons), faint grey is kept
  for disabled controls only, and selected rows switch their grey text to
  white.
- On narrow phones (under 400 dp) the Print button shows its printer icon
  alone instead of a clipped label, and the Print Preview title shortens
  with "…" first.
- Release signing from a `keystore.properties` kept out of source control,
  and `./gradlew release -Pversion=… -Pnotes=…`, which bumps the version,
  dates the changelog and builds `MaktabatiPro-<version>.apk` and `.aab`.
- **Print Preview**: the sheet at true paper scale on the dark workspace
  (100 % is life-size on this screen), with page navigation and zoom. A
  settings panel (side panel on a tablet, bottom sheet on a phone) offers
  **All pages / Current page only / Custom range** (`1-3, 5`), a thumbnail
  of every page marked *Will print* or *Skipped*, and a summary such as
  `2 pages to print · 2 of 3 selected · 2 sheets of paper`. A range such as
  `0-2`, `7-9` or `a-b` is refused with a clear message and nothing prints.
- **Print** builds a PDF of the selected pages (ISO A4, 300 dpi, each page
  drawn over the whole sheet) and hands it to Android's print dialog, where
  the printer, copies, double-sided and paper size are chosen. The PDF
  depends on the layout and the chosen pages only, never on the preview zoom.
- **Share** sends that PDF to an app you pick; **Save as PDF** saves it where
  you choose. Only the latest print PDF is kept in the app's private cache.
- **Save A4**: every page is rendered at 300 dpi (2480 × 3508 px) and saved as
  `Full_Doc.pdf` plus `Page_1.jpg`, `Page_2.jpg` … in a new folder
  `Documents/مكتبتي برو/Jaafer_Scan_<date>_<time>`, as the desktop names
  them. The PDF has ISO A4 pages with each page image drawn over the whole
  sheet, so a card prints at 85.6 × 54 mm. The JPEG pages carry 300 dpi, so
  they also print at true size from a photo viewer. "Open PDF" opens the
  result. The PDF depends on the layout only: saving at 25 %, 100 % or 300 %
  zoom gives byte-identical files.
- **Export IDs**: each source image saved as `ID_Card_<n>_<size>KB.jpg`
  under the size limit (default 100 KB) in `ID_Export_<date>_<time>`. The
  desktop ladder: quality from 95 down in steps of 5, then 80 % smaller and
  quality 85 again, never below 100 px. Images that cannot reach the limit are
  listed and not written.
- Files are saved through MediaStore with no storage permission. On Android 9
  and older the app asks once for a folder (system folder picker) and keeps
  using it.
- Print Layout screen: an A4 page on the dark workspace with a drop shadow and
  millimetre rulers along the top and left. Items are stored in page pixels,
  so zooming never changes the printed result.
  - **Sources**: every image in the session, ready to add to the page at ID
    card size (85.60 × 53.98 mm; a portrait source gets it turned). Sources
    can be turned or removed from the list; copies already placed stay.
    **Import** adds more images, which go through crop and adjust and then
    join the list.
  - **Layers**: thumbnail, name, printed size in mm, show/hide, lock, and a
    menu with bring forward / send backward, duplicate, size presets and
    delete.
  - Drag an item to move it; it is always kept inside the page. Long-press for
    Rotate, Duplicate, ID card size, Passport size (125 × 88 mm), Fit to page
    (10 mm margin, as the desktop) and Delete. Locked items stay put.
  - **Text** labels at the desktop's size and position (Arabic is shaped by
    Android). Long text widens the label instead of being cut off.
  - **Grid** (quarter lines, never printed), **Undo** (move, rotate, resize,
    duplicate, delete, add), multiple pages with first / previous / next /
    last, **New Page** after the current one, delete an empty page, and
    **Clean Up** to keep only the first page.
  - Zoom out / in on the desktop's steps (25 % … 300 %, where 100 % is life
    size on this screen), pinch to zoom, drag to pan, Fit.
  - Phones show Layers and Sources as bottom sheets; wide tablets show them
    as side panels, like the desktop.
  - Placed images get the desktop's rounded corners (40 px at source size).
  - The layout is saved with the session and comes back after the app is
    closed.
- Adjust screen (`Image 2 of 5`, Previous / Next): Brightness, Contrast,
  Sharpness and Saturation sliders from −100 to +100 with 0 in the middle,
  each with a number box you can type into. The slider track fills from the
  centre, so an untouched slider looks empty. Settings are kept per image and
  saved with the session.
- **Auto Enhance**, **Reset** and **Apply to all**, behaving as on the desktop:
  Auto Enhance enhances the image and sets the sliders back to 0 (press again
  to turn it off); Apply to all copies the slider positions to every image;
  Reset returns the image to how it came out of the crop step.
- Press and hold the image to see it without your changes; release to see
  the edit again.
- Pinch to zoom, drag to pan, zoom out / zoom in buttons on the desktop's steps
  (25 % … 300 %, real image pixels), and Fit.
- **Continue** renders every edited image at full resolution (only images
  whose settings changed since the last render) and opens the layout. The
  live preview works on a reduced copy, so dragging a slider never touches the
  full-size image.
- The image engine is ported 1:1 from the desktop `engine.py` and checked
  against it: run on the same input, the Android result matches the desktop
  result to within JPEG encoding noise.
- **Open Images** opens a bottom sheet with Camera, Gallery and Files. Gallery
  uses the system Photo Picker and Files uses the document picker; both take
  many images at once and need no permission. Camera (CameraX) takes several
  photos in a row and asks for camera access only when it is first used, with
  a short explanation.
- Imported images are stored upright (photo rotation applied) and capped at
  4096 px on the long side, in app-private storage that is never backed up.
- The session is saved after every change: if the app is closed or killed,
  **Continue last session** on the welcome screen picks up where you left off.
  Starting a new session asks first; **Exit** in the crop screen discards it.
- Crop screen: tap four corners (numbered markers, joined by a line, area
  tinted), long-press a marker to drag it, Undo, Rotate, pinch to zoom,
  two-finger pan, double-tap to fit. ID Card / A4 Document selector,
  `Corners 2 / 4` and `1 / 7` counters, **Skip Crop** and **Save & Next**.
  On tablets and in landscape the two buttons sit in the toolbar.
- Perspective crop ported 1:1 from the desktop engine (corner ordering, output
  ratio 1.585 for ID cards and 1.414 for A4, degenerate quads keep the original
  image), run at full resolution off the main thread.
- **Auto-detect edges** finds the document outline and pre-fills the four
  corners for you to check; it never crops on its own. Works offline with
  OpenCV, and checks each colour channel so coloured card bands are not
  mistaken for the edge.
- Every failure (an unreadable file, a failed crop, the camera not starting)
  is logged and shown on screen.

- Layout geometry (`core/layout`), the measurement rules every printout depends
  on, covered by unit tests:
  - A4 page of 2480 × 3508 px at 300 dpi; 2480 / 210 px per millimetre.
  - Size presets: ID card 85.60 × 53.98 mm (1011 × 637 px), passport
    125 × 88 mm (1476 × 1039 px), fit to page. A portrait source gets the
    preset turned, so an upright card prints 53.98 × 85.60 mm.
  - Positions are stored in page pixels and rounded (never truncated) only when
    rendering, so cards don't print short and the printout is identical at any
    zoom.
  - Items are kept inside the page whenever they are added, moved, rotated,
    resized or duplicated, so nothing is cropped at print time. Fixes the
    desktop bug where a passport lost 23 mm off the top edge.
  - New items take the first free spot on the page instead of a fixed position.
  - Multi-page model with lock, hide, duplicate and delete; locked items can't
    be moved, rotated, resized or deleted.
  - Zoom ladders from the desktop (layout and adjust screens).
- Project skeleton: Kotlin, Jetpack Compose + Material 3, Hilt, Compose
  Navigation, Gradle Kotlin DSL with a version catalog. The app version lives
  in one place (`gradle/libs.versions.toml`) and appears on the welcome screen
  and in the APK filename.
- The original logo as the launcher icon (adaptive icon on a solid `#1E508B`
  background), on the splash screen, and on the welcome card.
- Colour tokens ported from the desktop program, with the dark working theme as
  the default.
- Welcome screen: blue gradient, white card with the logo, title, subtitle,
  **Open Images** and **Settings** buttons, and the version in the corner.
  The card turns dark when the system is in dark mode.
- Navigation graph in the fixed screen order (Welcome → Crop → Adjust →
  Layout → Print, plus Settings). Screens not built yet show a placeholder.
- No network permission and no cloud backup: identity documents never leave
  the device.

### Fixed
- Four corners tapped in quick succession were taken as two double-taps (zoom
  to fit) and dropped. A double-tap now only counts when both taps land in the
  same spot.

### Changed
- Perspective crop sizes are now truncated exactly as the desktop does
  (`int()`), so a crop can be one pixel smaller than before. Print geometry
  still rounds; this only sizes the cropped image.
- Release builds carry OpenCV for ARM phones only (arm64-v8a, armeabi-v7a);
  debug builds add x86_64 for the emulator.
- A network-state permission pulled in by the camera library is removed, so
  the app still declares no network permission at all.
